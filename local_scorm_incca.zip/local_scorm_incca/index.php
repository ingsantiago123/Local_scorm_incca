<?php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

require_login();
require_capability('local/scorm_incca:viewadminpanel', context_system::instance());

if (is_siteadmin()) {
    admin_externalpage_setup('local_scorm_incca_items');
} else {
    $PAGE->set_context(context_system::instance());
    $PAGE->set_url(new moodle_url('/local/scorm_incca/index.php'));
    $PAGE->set_pagelayout('standard');
}

// ── Helper interno de limpieza ────────────────────────────────────────────────
// Verifica cada registro contra course_modules y elimina los huérfanos.
// Considera también módulos marcados para eliminación asíncrona (deletioninprogress=1).
function scorm_incca_delete_orphans(): int {
    global $DB;
    $items   = $DB->get_records('local_scorm_incca_items', [], '', 'id, cmid');
    $deleted = 0;
    foreach ($items as $item) {
        // Un registro es válido si: course_module existe, es tipo scorm, y NO está pendiente de borrar.
        $valid = $DB->record_exists_sql(
            "SELECT 1
               FROM {course_modules} cm
               JOIN {modules} m ON m.id = cm.module AND m.name = 'scorm'
              WHERE cm.id = :cmid
                AND (cm.deletioninprogress = 0 OR cm.deletioninprogress IS NULL)",
            ['cmid' => (int)$item->cmid]
        );
        if (!$valid) {
            $DB->delete_records('local_scorm_incca_items', ['cmid' => (int)$item->cmid]);
            $deleted++;
        }
    }
    return $deleted;
}

// ── Auto-sincronización silenciosa al cargar el panel ────────────────────────
// Limpia fantasmas antes de mostrar datos, sin interrumpir si falla.
try {
    scorm_incca_delete_orphans();
} catch (\Throwable $e) {
    // No romper el panel si la limpieza falla.
}

// ── Acciones POST ────────────────────────────────────────────────────────────
$action = optional_param('action', '', PARAM_ALPHA);
$cmid   = optional_param('cmid', 0, PARAM_INT);

if ($action === 'toggle' && $cmid && confirm_sesskey()) {
    $rec    = $DB->get_record('local_scorm_incca_items', ['cmid' => $cmid], '*', MUST_EXIST);
    $newval = $rec->isprotected ? 0 : 1;
    $DB->set_field('local_scorm_incca_items', 'isprotected', $newval, ['cmid' => $cmid]);
    $DB->set_field('local_scorm_incca_items', 'timemodified', time(), ['cmid' => $cmid]);
    $label  = $newval ? 'PROTEGIDO' : 'PUBLICO';
    \local_scorm_incca\helper::log(
        \local_scorm_incca\helper::LOG_UPLOAD_PROTECTED,
        (int)$USER->id,
        $cmid,
        "Estado cambiado manualmente a {$label} | cmid={$cmid} por userid={$USER->id}"
    );
    redirect(
        new moodle_url('/local/scorm_incca/index.php', ['filter' => optional_param('filter', 'all', PARAM_ALPHA)]),
        "SCORM cmid={$cmid} ahora es {$label}.",
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

if ($action === 'cleanup' && confirm_sesskey()) {
    try {
        $deleted = scorm_incca_delete_orphans();
        redirect(
            new moodle_url('/local/scorm_incca/index.php'),
            "Limpieza: {$deleted} registros huérfanos eliminados.",
            null,
            \core\output\notification::NOTIFY_SUCCESS
        );
    } catch (\Throwable $e) {
        redirect(
            new moodle_url('/local/scorm_incca/index.php'),
            "Error en limpieza: " . $e->getMessage(),
            null,
            \core\output\notification::NOTIFY_ERROR
        );
    }
}

// ── Encabezado ───────────────────────────────────────────────────────────────
$filter = optional_param('filter', 'all', PARAM_ALPHA);

$PAGE->set_title(get_string('protected_list', 'local_scorm_incca'));
$PAGE->set_heading(get_string('protected_list', 'local_scorm_incca'));
echo $OUTPUT->header();

// ── Barra de filtros y acciones ───────────────────────────────────────────────
echo html_writer::start_div('mb-3 d-flex gap-2 flex-wrap align-items-center');

// Filtros
$filtersMap = [
    'all'       => get_string('filter_all', 'local_scorm_incca'),
    'protected' => get_string('filter_protected', 'local_scorm_incca'),
    'public'    => get_string('filter_public', 'local_scorm_incca'),
];
foreach ($filtersMap as $key => $label) {
    $url = new moodle_url('/local/scorm_incca/index.php', ['filter' => $key]);
    $cls = ($filter === $key) ? 'btn btn-primary' : 'btn btn-outline-primary';
    echo html_writer::link($url, $label, ['class' => $cls . ' mr-2']);
}

echo '&nbsp;&nbsp;';

// Limpiar huérfanos
$cleanupurl = new moodle_url('/local/scorm_incca/index.php', ['action' => 'cleanup', 'sesskey' => sesskey()]);
echo html_writer::link($cleanupurl, $OUTPUT->pix_icon('t/delete', '') . ' Limpiar huérfanos', [
    'class'   => 'btn btn-outline-danger mr-2',
    'title'   => 'Elimina registros de SCORMs que ya fueron borrados de Moodle',
    'onclick' => 'return confirm("¿Eliminar registros de SCORMs que ya no existen en Moodle?")',
]);

echo html_writer::end_div();

// ── Tabla de items ─────────────────────────────────────────────────────────────
$where = '1=1';
if ($filter === 'protected') $where = 'i.isprotected = 1';
if ($filter === 'public')    $where = 'i.isprotected = 0';

$sql = "SELECT i.id, i.cmid, i.scormid, i.courseid, i.isprotected, i.timecreated, i.timemodified,
               u.firstname, u.lastname, u.email,
               c.fullname AS coursename, c.shortname,
               s.name AS scormname
          FROM {local_scorm_incca_items} i
          LEFT JOIN {user}   u ON u.id = i.creatorid
          LEFT JOIN {course} c ON c.id = i.courseid
          LEFT JOIN {scorm}  s ON s.id = i.scormid
         WHERE {$where}
         ORDER BY i.timemodified DESC";

$records = $DB->get_records_sql($sql);

if (empty($records)) {
    echo $OUTPUT->notification(get_string('no_records', 'local_scorm_incca'), 'info');
} else {
    $table = new html_table();
    $table->head = [
        get_string('th_status',  'local_scorm_incca'),
        get_string('th_scorm',   'local_scorm_incca'),
        get_string('th_course',  'local_scorm_incca'),
        get_string('th_creator', 'local_scorm_incca'),
        get_string('th_created', 'local_scorm_incca'),
        'Acciones',
    ];
    $table->attributes['class'] = 'generaltable';

    foreach ($records as $r) {
        $statusbadge = $r->isprotected
            ? html_writer::tag('span', $OUTPUT->pix_icon('t/locked', '') . ' ' . get_string('protected_badge', 'local_scorm_incca'),
                ['class' => 'badge badge-danger', 'style' => 'font-size:12px'])
            : html_writer::tag('span', $OUTPUT->pix_icon('t/unlocked', '') . ' ' . get_string('public_badge', 'local_scorm_incca'),
                ['class' => 'badge badge-secondary', 'style' => 'font-size:12px']);

        $scormlink = ($r->cmid && $r->scormname)
            ? html_writer::link(new moodle_url('/mod/scorm/view.php', ['id' => $r->cmid]),
                format_string($r->scormname))
            : ($r->scormname ? format_string($r->scormname) : '-');

        $courselink = ($r->courseid && $r->coursename)
            ? html_writer::link(new moodle_url('/course/view.php', ['id' => $r->courseid]),
                format_string($r->coursename))
            : '-';

        $creator = trim(($r->firstname ?? '') . ' ' . ($r->lastname ?? ''));
        if ($r->email) {
            $creator .= html_writer::empty_tag('br') . html_writer::tag('small', s($r->email), ['class' => 'text-muted']);
        }

        $togglelabel = $r->isprotected
            ? $OUTPUT->pix_icon('t/unlocked', '') . ' Hacer Público'
            : $OUTPUT->pix_icon('t/locked', '') . ' Proteger';
        $toggleclass = $r->isprotected ? 'btn btn-sm btn-outline-secondary' : 'btn btn-sm btn-outline-danger';
        $toggleurl   = new moodle_url('/local/scorm_incca/index.php', [
            'action'  => 'toggle',
            'cmid'    => $r->cmid,
            'sesskey' => sesskey(),
            'filter'  => $filter,
        ]);
        $toggleconfirm = $r->isprotected
            ? "¿Hacer PÚBLICO este SCORM? Cualquier usuario podrá descargarlo."
            : "¿Marcar este SCORM como PROTEGIDO? Solo usuarios con permiso podrán descargarlo.";

        $actions  = html_writer::link($toggleurl, $togglelabel, [
            'class'   => $toggleclass . ' mr-1',
            'onclick' => "return confirm(" . json_encode($toggleconfirm) . ")",
        ]);
        $actions .= '&nbsp;';
        $actions .= html_writer::link(
            new moodle_url('/local/scorm_incca/logs.php', ['cmid' => $r->cmid]),
            get_string('view_logs', 'local_scorm_incca'),
            ['class' => 'btn btn-sm btn-secondary']
        );

        $table->data[] = [
            $statusbadge,
            $scormlink,
            $courselink,
            $creator ?: '-',
            userdate($r->timecreated),
            $actions,
        ];
    }

    echo html_writer::table($table);
}

echo $OUTPUT->footer();