<?php
namespace local_scorm_incca;

defined('MOODLE_INTERNAL') || die();

use core\event\course_module_created;
use core\event\course_module_updated;
use core\event\course_module_deleted;

/**
 * Observa la creacion y eliminacion de actividades para registrar SCORMs.
 */
class observer {

    /**
     * Cuando se crea una actividad SCORM, se registra en el plugin.
     * Si el creador tiene local/scorm_incca:cargar -> protegido.
     * Si no la tiene -> publico (registrado igual para visibilidad en el panel).
     */
    public static function course_module_created(course_module_created $event): void {
        self::handle_create_or_update($event);
    }

    /**
     * Re-evalua la proteccion si se actualiza el course module.
     * Util si cambia el rol del usuario o se reasigna la actividad.
     */
    public static function course_module_updated(course_module_updated $event): void {
        self::handle_create_or_update($event);
    }

    /**
     * Limpia el registro cuando se elimina la actividad SCORM.
     *
     * Se dispara tanto en eliminación síncrona (inmediata) como en eliminación
     * asíncrona de Moodle (cuando el adhoc task del cron finaliza la operación).
     * En ambos casos el registro del plugin debe desaparecer.
     */
    public static function course_module_deleted(course_module_deleted $event): void {
        $modulename = $event->other['modulename'] ?? '';
        if ($modulename !== 'scorm') {
            return;
        }

        try {
            $cmid = (int)$event->contextinstanceid;
            helper::unregister_scorm($cmid);
            helper::log(helper::LOG_DELETED, (int)$event->userid, $cmid,
                "Registro eliminado para cmid {$cmid}");
        } catch (\Throwable $e) {
            // Silenciar para no interrumpir el proceso de eliminación de Moodle.
        }
    }

    /**
     * Logica compartida para create / update.
     */
    private static function handle_create_or_update($event): void {
        $modulename = $event->other['modulename'] ?? '';
        if ($modulename !== 'scorm') {
            return;
        }

        try {
            $cmid     = $event->contextinstanceid;
            $scormid  = (int)($event->other['instanceid'] ?? 0);
            $courseid = (int)$event->courseid;
            $userid   = (int)$event->userid;

            // Solo persiste si el course module existe (defensive).
            $context = \context_module::instance($cmid, IGNORE_MISSING);
            if (!$context) {
                return;
            }

            $isprotected = has_capability('local/scorm_incca:cargar', $context, $userid);

            helper::register_scorm($cmid, $scormid, $courseid, $userid, $isprotected);

            $type = $isprotected ? helper::LOG_UPLOAD_PROTECTED : helper::LOG_UPLOAD_PUBLIC;
            $msg  = $isprotected
                ? "SCORM cmid={$cmid} marcado como protegido (creador userid={$userid})"
                : "SCORM cmid={$cmid} registrado como publico (creador userid={$userid})";

            helper::log($type, $userid, $cmid, $msg);

        } catch (\Throwable $e) {
            helper::log(helper::LOG_ERROR, (int)$event->userid, $event->contextinstanceid ?? null,
                "Error en observer: " . $e->getMessage());
        }
    }
}
