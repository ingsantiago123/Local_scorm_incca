# local_scorm_incca

**Tipo de plugin:** Local (local)  
**Componente:** local_scorm_incca  
**Version:** 1.0.10  
**Moodle requerido:** 4.5+  
**PHP requerido:** 8.1+  
**Autor:** Kevin Garzon — Universidad INCCA de Colombia  
**Licencia:** GNU GPL v3 or later

---

## Descripcion general

`local_scorm_incca` es un plugin de proteccion de paquetes SCORM para Moodle. Permite
clasificar cada actividad SCORM como **protegida** o **publica**, controlando quienes pueden
descargar el archivo `.zip` del paquete segun capabilities especificas asignadas por el
administrador. La proteccion se aplica a nivel de archivo, interceptando todas las rutas de
descarga posibles antes de que Moodle sirva el contenido.

Ademas de la proteccion de descarga, el plugin bloquea la eliminacion y descompresion de
paquetes protegidos por parte de usuarios sin los permisos adecuados, y registra en una
tabla de auditoria todos los eventos relevantes.

---

## Requisitos

- Moodle 4.5 o superior (requiere el sistema de hooks introducido en Moodle 4.4)
- PHP 8.1 o superior
- Base de datos: MySQL 5.7+ / MariaDB 10.4+ / PostgreSQL 13+
- El modulo `mod_scorm` debe estar instalado y activo en el sitio

---

## Instalacion

1. Descomprimir o copiar el directorio `local_scorm_incca` en `{moodleroot}/local/`.
2. Acceder como administrador a `Administracion del sitio > Notificaciones`.
3. Ejecutar la actualizacion de base de datos cuando Moodle lo solicite.
4. Purgar todas las caches: `Administracion del sitio > Desarrollo > Purgar todas las caches`.

Al instalar, el plugin escanea automaticamente todos los SCORMs existentes en el sitio y los
registra. Si el creador del SCORM tiene la capability `local/scorm_incca:cargar` en el momento
de la instalacion, el registro queda marcado como protegido; en caso contrario, como publico.

**Reinstalacion limpia:**

1. Desinstalar el plugin: `Administracion del sitio > Plugins > Informacion del plugin > Desinstalar`.
2. Purgar caches.
3. Instalar la nueva version subiendo el ZIP desde `Administracion del sitio > Plugins > Instalar plugins`.
4. Purgar caches nuevamente tras la instalacion.

---

## Funcionalidades

### Proteccion de descarga

Cuando un SCORM esta marcado como protegido (`isprotected = 1`), el plugin bloquea
el acceso al archivo `.zip` del paquete para cualquier usuario que no tenga la
capability `local/scorm_incca:descargar` en el contexto del curso correspondiente.
Los site admins tienen acceso irrestricto en todos los casos.

Vectores de descarga bloqueados:

| Ruta | Descripcion |
|------|-------------|
| `pluginfile.php/{ctx}/mod_scorm/package/{rev}/{file}.zip` | Descarga directa del paquete desde el reproductor SCORM o enlace directo |
| `draftfile.php/{ctx}/user/draft/{id}/{file}.zip` | Descarga desde el gestor de archivos al editar la actividad |
| `draftfiles_ajax.php?action=downloadselected` | Descarga masiva como ZIP desde el gestor de archivos |
| `draftfiles_ajax.php?action=unzip` | Descompresion del paquete dentro del gestor de archivos |
| `draftfiles_ajax.php?action=delete` | Eliminacion del archivo .zip desde el gestor de archivos al editar |

### Proteccion de eliminacion del modulo

Cuando un usuario intenta eliminar una actividad SCORM protegida desde la vista del
curso, el plugin intercepta la solicitud. Solo pueden eliminar un SCORM protegido:

- Site admins
- Usuarios con `local/scorm_incca:cargar` en el contexto del modulo
- Usuarios con `local/scorm_incca:descargar` en el contexto del modulo

La eliminacion se intercepta en dos puntos complementarios:

1. `lib/ajax/service.php` — para solicitudes del editor de cursos de Moodle 4.x
   (acciones `core_courseformat_update_course` con `action=cm_delete` y
   `core_course_edit_module` con `action=delete`)
2. `local_scorm_incca_pre_course_module_delete()` — hook legacy que actua como red
   de seguridad para eliminaciones sincronas via `course/mod.php`

### Registro automatico de SCORMs

Al crear o actualizar una actividad SCORM, el plugin registra automaticamente el
modulo en su tabla propia. El estado de proteccion se determina segun si el usuario
que realiza la accion tiene la capability `local/scorm_incca:cargar` en el curso.

- Si tiene la capability: el SCORM queda registrado como **protegido**
- Si no la tiene: queda registrado como **publico**

El estado de proteccion puede modificarse manualmente desde el panel de administracion
en cualquier momento.

### Panel de administracion

Accesible desde `Administracion del sitio > Extensiones > Plugins locales > SCORM INCCA`
(para site admins) o mediante el bloque `block_scorm_incca` (para usuarios con
`viewadminpanel`).

El panel incluye tres secciones:

**Paquetes SCORM registrados** (`index.php`)
- Lista todos los SCORMs registrados con estado de proteccion, nombre, curso y creador
- Permite filtrar por estado: todos / protegidos / publicos
- Permite cambiar el estado de proteccion de cada SCORM individualmente
- Boton de limpieza de registros huerfanos (SCORMs eliminados de Moodle pero con
  registro remanente en la tabla del plugin)

**Logs de auditoria** (`logs.php`)
- Muestra todos los eventos registrados con tipo, usuario, SCORM afectado,
  direccion IP y fecha
- Filtros por tipo de evento y por SCORM (cmid)
- Paginacion de 50 registros por pagina

**Usuarios con permisos personalizados** (`users.php`) — exclusivo para site admins
- Lista los usuarios que tienen asignadas las capabilities `cargar` o `descargar`
  en cualquier rol del sistema

---

## Capabilities

### local/scorm_incca:cargar

| Propiedad | Valor |
|-----------|-------|
| Tipo | write |
| Contexto | CONTEXT_COURSE |
| Archetype por defecto | manager: CAP_ALLOW |

Otorga el derecho a subir paquetes SCORM que queden registrados como protegidos.
Cuando un usuario con esta capability crea o actualiza un SCORM, el plugin lo marca
como protegido automaticamente. Tambien permite eliminar SCORMs protegidos.

**Donde asignar:** en el contexto del curso especifico (override de rol en el curso)
o en un rol a nivel de curso/categoria.

### local/scorm_incca:descargar

| Propiedad | Valor |
|-----------|-------|
| Tipo | read |
| Contexto | CONTEXT_COURSE |
| Archetype por defecto | manager: CAP_ALLOW |

Otorga el derecho a descargar el archivo `.zip` de un SCORM protegido.
Sin esta capability, cualquier intento de descarga (directa, desde borrador, ZIP masivo,
descompresion, eliminacion del archivo) es bloqueado.

**Donde asignar:** en el contexto del curso especifico o en un rol a nivel de curso/categoria.

### local/scorm_incca:viewadminpanel

| Propiedad | Valor |
|-----------|-------|
| Tipo | read |
| Contexto | CONTEXT_SYSTEM |
| Archetype por defecto | manager: CAP_ALLOW |

Otorga acceso al panel de administracion del plugin (lista de SCORMs y logs).
La pagina `users.php` (usuarios con permisos) solo es accesible para site admins.

**Donde asignar:** obligatoriamente a nivel SISTEMA. Ir a
`Administracion del sitio > Usuarios > Permisos > Asignar roles del sistema` y
asignar un rol que incluya esta capability. Si se asigna en un contexto inferior
(curso, categoria), la verificacion del plugin no la detectara.

---

## Arquitectura tecnica

### Hooks y callbacks

El plugin no modifica ningun archivo del nucleo de Moodle. Toda la logica se ejecuta
mediante el sistema de hooks y callbacks legacy de Moodle.

**Hook `\core\hook\after_config`** (db/hooks.php)

Se dispara al final de `lib/setup.php` para cada peticion HTTP. El plugin filtra
unicamente las peticiones a los endpoints relevantes:

- `pluginfile.php`
- `draftfile.php`
- `repository/draftfiles_ajax.php`
- `lib/ajax/service.php`

Para estas peticiones, carga explicitamente las clases del plugin (sin depender del
autoloader, ya que algunos endpoints definen `NO_DEBUG_DISPLAY` antes de cargar
config.php) y ejecuta `hook_callbacks::check_access()`.

**Callback legacy `local_scorm_incca_after_require_login`** (lib.php)

Actua como mecanismo de respaldo. Se dispara dentro de `require_login()` en los
endpoints que llaman a esa funcion. Un guard estatico basado en `REQUEST_TIME_FLOAT`
evita la doble ejecucion cuando ambos mecanismos disparan en la misma peticion.

**Callback legacy `local_scorm_incca_pre_course_module_delete`** (lib.php)

Se dispara desde `course_delete_module()` en la ruta de eliminacion sincrona
(`course/mod.php`). Lanza una `moodle_exception` para cancelar la eliminacion si el
usuario no tiene los permisos necesarios.

### Observadores de eventos

Declarados en `db/events.php`.

| Evento | Handler | Accion |
|--------|---------|--------|
| `\core\event\course_module_created` | `observer::course_module_created` | Registra el SCORM en la tabla del plugin con estado segun capability del creador |
| `\core\event\course_module_updated` | `observer::course_module_updated` | Actualiza el registro existente |
| `\core\event\course_module_deleted` | `observer::course_module_deleted` | Elimina el registro del plugin |

### Identificacion del SCORM en areas de borrador

Cuando el plugin necesita determinar si un archivo ZIP en un area de borrador
pertenece a un SCORM protegido, usa el metodo `helper::find_protected_scorm_by_draft()`.

Este metodo implementa dos estrategias en orden de prioridad:

1. **Campo `source` del borrador (preciso):** Moodle guarda en `mdl_files.source`
   un objeto PHP serializado con la referencia al archivo original. El campo
   `original` contiene un `pack_reference` (base64 de un objeto serializado) que
   incluye el `contextid` del SCORM original. Con ese contextid se obtiene el cmid
   directamente.

2. **Fallback por `contenthash` (postura de seguridad):** Si el campo source no
   permite identificar el SCORM exacto, el plugin busca todos los SCORMs registrados
   con el mismo hash de contenido. Si alguno es protegido, bloquea (postura
   conservadora cuando la identidad exacta no puede determinarse).

---

## Tablas de base de datos

### mdl_local_scorm_incca_items

Almacena el estado de proteccion de cada actividad SCORM registrada.

| Campo | Tipo | Descripcion |
|-------|------|-------------|
| id | INT(10) | Clave primaria autoincremental |
| cmid | INT(10) | Clave unica. Referencia a `mdl_course_modules.id` |
| scormid | INT(10) | Referencia a `mdl_scorm.id` |
| courseid | INT(10) | Referencia a `mdl_course.id` |
| creatorid | INT(10) | Usuario que creo la actividad. Referencia a `mdl_user.id` |
| isprotected | INT(1) | Estado de proteccion: 1 = protegido, 0 = publico |
| timecreated | INT(10) | Timestamp Unix de creacion del registro |
| timemodified | INT(10) | Timestamp Unix de ultima modificacion |

Indices: `isprotected` (no unico), `creatorid` (no unico).

### mdl_local_scorm_incca_logs

Registro de auditoria de todos los eventos del plugin.

| Campo | Tipo | Descripcion |
|-------|------|-------------|
| id | INT(10) | Clave primaria autoincremental |
| eventtype | CHAR(64) | Tipo de evento (ver tabla de tipos abajo) |
| userid | INT(10) | Usuario que genero el evento |
| cmid | INT(10) | SCORM afectado (nullable) |
| message | TEXT | Descripcion detallada del evento |
| ipaddress | CHAR(45) | Direccion IP del cliente |
| timecreated | INT(10) | Timestamp Unix del evento |

Indices: `eventtype`, `timecreated`, `cmid` (no unicos).

**Tipos de evento (`eventtype`):**

| Valor | Descripcion |
|-------|-------------|
| `upload_protected` | SCORM subido y registrado como protegido |
| `upload_public` | SCORM subido y registrado como publico |
| `download_allowed` | Descarga del paquete permitida |
| `download_blocked` | Descarga del paquete bloqueada |
| `deleted` | Registro eliminado al borrarse el SCORM de Moodle |
| `error` | Error en la ejecucion de la logica del plugin |
| `delete_blocked` | Intento de eliminacion del modulo SCORM bloqueado |
| `unzip_blocked` | Intento de descompresion del paquete bloqueado |

---

## Estructura de archivos

```
local/scorm_incca/
├── classes/
│   ├── helper.php            Logica de negocio central: registro, logs, parseo de rutas,
│   │                         identificacion de borradores y SCORMs protegidos
│   ├── hook_callbacks.php    Punto de entrada para todos los hooks del plugin.
│   │                         Implementa check_access() y los handlers por endpoint
│   ├── observer.php          Handlers de eventos Moodle (creacion, edicion, eliminacion)
│   └── privacy/
│       └── provider.php      Declaracion GDPR: el plugin no almacena datos personales
│                             mas alla de lo necesario para la funcionalidad de auditoria
├── db/
│   ├── access.php            Definicion de capabilities
│   ├── events.php            Registro de observadores de eventos
│   ├── hooks.php             Registro del hook after_config
│   ├── install.php           Escaneo y registro de SCORMs existentes al instalar
│   ├── install.xml           Schema XMLDB de las dos tablas del plugin
│   └── uninstall.php         Limpieza explicita de datos antes de que Moodle elimine tablas
├── lang/
│   ├── en/local_scorm_incca.php
│   └── es/local_scorm_incca.php
├── index.php                 Panel: lista de SCORMs registrados, toggle de estado, limpieza
├── lib.php                   Callbacks legacy: after_require_login, pre_course_module_delete
├── logs.php                  Panel: visor de logs de auditoria con filtros
├── settings.php              Registro de paginas en el arbol de administracion de Moodle
├── users.php                 Panel (solo admin): usuarios con capabilities del plugin
└── version.php
```

---

## Desinstalacion

El archivo `db/uninstall.php` realiza una limpieza completa antes de que Moodle elimine
las tablas:

- Elimina todos los registros de `mdl_local_scorm_incca_items`
- Elimina todos los registros de `mdl_local_scorm_incca_logs`

Moodle se encarga automaticamente de:

- Eliminar las tablas declaradas en `db/install.xml`
- Revocar capabilities, eliminar configuraciones del plugin y desregistrar observers

El proceso de desinstalacion no modifica ninguna tabla del nucleo de Moodle. Los SCORMs,
cursos, usuarios, archivos y matriculas permanecen intactos.

---

## Compatibilidad

| Componente | Version minima |
|------------|----------------|
| Moodle | 4.5 |
| PHP | 8.1 |
| MySQL / MariaDB | 5.7 / 10.4 |
| PostgreSQL | 13 |
| mod_scorm | Incluido en Moodle 4.5 |

El plugin no requiere configuracion especifica de servidor web. Funciona con Apache y Nginx
sin modificaciones en `.htaccess` ni en la configuracion del servidor.

---

## Plugin complementario

El bloque `block_scorm_incca` proporciona acceso rapido al panel de administracion para
usuarios con la capability `viewadminpanel`. Debe instalarse por separado.
