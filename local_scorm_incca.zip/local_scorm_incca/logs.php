<?php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

require_login();
require_capability('local/scorm_incca:viewadminpanel', context_system::instance());

if (is_siteadmin()) {
    admin_externalpage_setup('local_scorm_incca_logs');
} else {
    $PAGE->set_context(context_system::instance());
    $PAGE->set_url(new moodle_url('/local/scorm_incca/logs.php'));
    $PAGE->set_pagelayout('standard');
}

$cmid       = optional_param('cmid', 0, PARAM_INT);
$eventtype  = optional_param('eventtype', '', PARAM_ALPHANUMEXT);
$page       = optional_param('page', 0, PARAM_INT);
$perpage    = 50;

$PAGE->set_title(get_string('logs', 'local_scorm_incca'));
$PAGE->set_heading(get_string('logs', 'local_scorm_incca'));

echo $OUTPUT->header();

// Filtros.
$eventtypes = [
    ''                                => get_string('filter_all', 'local_scorm_incca'),
    \local_scorm_incca\helper::LOG_UPLOAD_PROTECTED  => get_string('log_upload_protected',  'local_scorm_incca'),
    \local_scorm_incca\helper::LOG_UPLOAD_PUBLIC     => get_string('log_upload_public',     'local_scorm_incca'),
    \local_scorm_incca\helper::LOG_DOWNLOAD_ALLOWED  => get_string('log_download_allowed',  'local_scorm_incca'),
    \local_scorm_incca\helper::LOG_DOWNLOAD_BLOCKED  => get_string('log_download_blocked',  'local_scorm_incca'),
    \local_scorm_incca\helper::LOG_DELETED           => get_string('log_deleted',           'local_scorm_incca'),
    \local_scorm_incca\helper::LOG_ERROR             => get_string('log_error',             'local_scorm_incca'),
    \local_scorm_incca\helper::LOG_DELETE_BLOCKED    => get_string('log_delete_blocked',    'local_scorm_incca'),
    \local_scorm_incca\helper::LOG_UNZIP_BLOCKED     => get_string('log_unzip_blocked',     'local_scorm_incca'),
];

echo html_writer::start_tag('form', ['method' => 'get', 'class' => 'form-inline mb-3']);
echo html_writer::select($eventtypes, 'eventtype', $eventtype, false,
    ['class' => 'form-control mr-2']);
echo html_writer::empty_tag('input', [
    'type'        => 'number',
    'name'        => 'cmid',
    'placeholder' => get_string('filter_by_cmid', 'local_scorm_incca'),
    'value'       => $cmid ?: '',
    'class'       => 'form-control mr-2',
]);
echo html_writer::empty_tag('input', [
    'type'  => 'submit',
    'value' => get_string('filter', 'local_scorm_incca'),
    'class' => 'btn btn-primary',
]);
echo html_writer::end_tag('form');

// Query.
$where  = [];
$params = [];

if (!empty($eventtype)) {
    $where[] = 'l.eventtype = :eventtype';
    $params['eventtype'] = $eventtype;
}

if (!empty($cmid)) {
    $where[] = 'l.cmid = :cmid';
    $params['cmid'] = $cmid;
}

$wheresql = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

$countsql = "SELECT COUNT(1) FROM {local_scorm_incca_logs} l {$wheresql}";
$total = $DB->count_records_sql($countsql, $params);

$sql = "SELECT l.id, l.eventtype, l.userid, l.cmid, l.message, l.ipaddress, l.timecreated,
               u.firstname, u.lastname
          FROM {local_scorm_incca_logs} l
          LEFT JOIN {user} u ON u.id = l.userid
          {$wheresql}
         ORDER BY l.timecreated DESC";

$records = $DB->get_records_sql($sql, $params, $page * $perpage, $perpage);

if (empty($records)) {
    echo $OUTPUT->notification(get_string('no_logs', 'local_scorm_incca'), 'info');
} else {
    $table = new html_table();
    $table->head = [
        get_string('th_when',      'local_scorm_incca'),
        get_string('th_eventtype', 'local_scorm_incca'),
        get_string('th_user',      'local_scorm_incca'),
        get_string('th_cmid',      'local_scorm_incca'),
        get_string('th_ip',        'local_scorm_incca'),
        get_string('th_message',   'local_scorm_incca'),
    ];
    $table->attributes['class'] = 'generaltable';

    $badgeclass = [
        'upload_protected'   => 'badge-info',
        'upload_public'      => 'badge-secondary',
        'download_allowed'   => 'badge-success',
        'download_blocked'   => 'badge-danger',
        'deleted'            => 'badge-warning',
        'error'              => 'badge-dark',
        'delete_blocked'     => 'badge-danger',
        'unzip_blocked'      => 'badge-warning',
    ];

    foreach ($records as $r) {
        $cls = $badgeclass[$r->eventtype] ?? 'badge-secondary';
        $badge = html_writer::tag('span', s($r->eventtype),
            ['class' => "badge {$cls}"]);

        $user = trim(($r->firstname ?? '') . ' ' . ($r->lastname ?? ''));
        if ($r->userid) {
            $user = html_writer::link(
                new moodle_url('/user/profile.php', ['id' => $r->userid]),
                $user ?: '#' . $r->userid
            );
        } else {
            $user = '-';
        }

        $table->data[] = [
            userdate($r->timecreated, '%Y-%m-%d %H:%M:%S'),
            $badge,
            $user,
            $r->cmid ? s($r->cmid) : '-',
            $r->ipaddress ? s($r->ipaddress) : '-',
            s($r->message),
        ];
    }

    echo html_writer::table($table);
    echo $OUTPUT->paging_bar($total, $page, $perpage,
        new moodle_url('/local/scorm_incca/logs.php',
            ['eventtype' => $eventtype, 'cmid' => $cmid]));
}

echo $OUTPUT->footer();
